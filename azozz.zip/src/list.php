<?php
$shaikh = array(
  array(),
  array( 'name' => 'علي بن عبد الرحمن الحذيفي' , 'href' => 'http://server9.mp3quran.net/hthfi/'),          //1
  array( 'name' => 'سعد الغامدي',    'href' => 'http://server7.mp3quran.net/s_gmd/'),                     //2
  array( 'name' => 'خالد القحطاني',   'href' => 'http://server10.mp3quran.net/qht/'),                      //3
  array( 'name' => 'عبد الباسط عبد الصمد',   'href' => 'http://server7.mp3quran.net/basit/'),              //4
  array( 'name' => 'فارس عباد',   'href' => 'http://server8.mp3quran.net/frs_a/'),                       //5
  array( 'name' => 'ناصر القطامي',   'href' => 'http://server6.mp3quran.net/qtm/'),                       //6
  array( 'name' => 'صلاح بو خاطر',   'href' => 'http://server8.mp3quran.net/bu_khtr/'),                  //7
  array( 'name' => 'أحمد بن علي العجمي',   'href' => 'http://server10.mp3quran.net/ajm/128/'),            //8
  array( 'name' => 'أبو بكر الشاطري',   'href' => 'http://server11.mp3quran.net/shatri/'),                //9
  array( 'name' => 'سعود الشريم',   'href' => 'http://server7.mp3quran.net/shur/'),                       //10
  array( 'name' => 'عبد الرحمن السديس',   'href' => 'http://server11.mp3quran.net/sds/'),                  //11
  array( 'name' => 'مشاري العفاسي',   'href' => 'http://server8.mp3quran.net/afs/'),                      //12
  array( 'name' => 'محمود علي البنا',   'href' => 'http://server8.mp3quran.net/bna/'),                    //13
  array( 'name' => 'محمود خليل الحصري',   'href' => 'http://server13.mp3quran.net/husr/'),                //14
  array( 'name' => 'محمد صديق المنشاوي',   'href' => 'http://server10.mp3quran.net/minsh/'),              //15
  array( 'name' => 'محمد جبريل',   'href' => 'http://server8.mp3quran.net/jbrl/'),                       //16
  array( 'name' => 'ماهر المعيقلي',   'href' => 'http://server12.mp3quran.net/maher_m/'),                 //17
  array( 'name' => 'محمد البراك',   'href' => 'http://server13.mp3quran.net/braak/'),                     //18
  array( 'name' => 'ياسر القرشي',   'href' => 'http://server9.mp3quran.net/qurashi/'),                    //19
  array( 'name' => 'ياسر الدوسري',   'href' => 'http://server11.mp3quran.net/yasser/'),                   //20

);
